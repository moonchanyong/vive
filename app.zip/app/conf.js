
const TRAY_ICON_PATH = '/img/vibe_tray_16.png';
const CONTROLLER_TEM_PATH = __dirname + '/controller.html';
const constants = {
  TRAY_ICON_PATH,
  CONTROLLER_TEM_PATH
};

Object.freeze(constants);

module.exports = constants;
